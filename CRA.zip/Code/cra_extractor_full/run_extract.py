import json, argparse, os
from src.agent import build_graph

def main():
    if os.path.exists(scenario_path):
        scenario = json.load(open(scenario_path))
        print("Loaded scenario:", scenario.get("title",""))
    app = build_graph()
    result = app.invoke({})
    print("Wrote:", result.get("table_path","artifacts/output/risk_table.xlsx"))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="config/example_scenario.json")
    args = ap.parse_args()
    main(args.scenario)

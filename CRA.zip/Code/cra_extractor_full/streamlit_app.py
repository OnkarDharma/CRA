
import os
import io
import json
from pathlib import Path
import pandas as pd
import streamlit as st

# Local imports from project
from src.agent import build_graph
from src.ingest_elastic import main as ingest_main

st.set_page_config(page_title="CRA Extractor – Risk Table Builder", layout="wide")
st.title("CRA Extractor – Risk Table Builder (Llama 3.1 + LangGraph + Elasticsearch)")

st.markdown('''
This UI lets you upload source documents, optionally ingest them into Elasticsearch (vector + BM25),
and generate a consolidated risk table with columns:
**Risk Id, Execution Risk, Mapped L3 Risk, L3 Risk Taxonomy**.
''')

# ---------- Session state ----------
if "questionnaire" not in st.session_state:
    st.session_state.questionnaire = None
if "initial_impact" not in st.session_state:
    st.session_state.initial_impact = None

DATA_DIR = "D:\\TCS\\CRA\\Code\\cra_extractor_full\\Loaded_Data"
DATA_DIR.mkdir(exist_ok=True, parents=True)

# ---------- 1) Upload source files ----------
st.header("1) Upload Inputs")
col1, col2, col3 = st.columns(3)

with col1:
    bc_file = st.file_uploader("Business Case (.docx/.txt/.csv/.xlsx)", type=["docx","txt","csv","xlsx"], key="bc")
with col2:
    qi_file = st.file_uploader("Change Impact Questionnaire (.xlsx/.csv)", type=["xlsx","csv"], key="qi")
with col3:
    prev_cra = st.file_uploader("Previous CRA (.docx/.txt/.csv/.xlsx)", type=["docx","txt","csv","xlsx"], key="pcra")

tax_file = st.file_uploader("L3 Taxonomy (.xlsx)", type=["xlsx"], key="tax")
proj_exec = st.file_uploader("Project Execution Risks (.xlsx)", type=["xlsx"], key="per")

def save_upload(f, name_hint: str):
    if f is None:
        return None
    suffix = Path(f.name).suffix.lower()
    out = DATA_DIR / f"{name_hint}{suffix}"
    out.write_bytes(f.read())
    return out

saved = {}
saved["business_case"] = save_upload(bc_file, "business_case")
saved["questionnaire"] = save_upload(qi_file, "questionnaire")
saved["previous_cra"] = save_upload(prev_cra, "previous_cra")
saved["taxonomy"] = save_upload(tax_file, "l3_taxonomy")
saved["project_risks"] = save_upload(proj_exec, "project_execution_risks")

with st.expander("Saved files (data/)", expanded=False):
    for k,v in saved.items():
        st.write(k, "→", str(v) if v else "—")

# Show Questionnaire as editable table with 'score' column
if saved["questionnaire"]:
    try:
        if str(saved["questionnaire"]).endswith(".xlsx"):
            qdf = pd.read_excel(saved["questionnaire"])
        else:
            qdf = pd.read_csv(saved["questionnaire"])
        if "score" not in qdf.columns:
            qdf["score"] = 0
        st.info("You can edit the 'score' column before calculating initial impact.")
        st.session_state.questionnaire = st.data_editor(qdf, use_container_width=True, num_rows="dynamic", key="qi_editor")
    except Exception as e:
        st.warning(f"Could not parse questionnaire: {e}")

# ---------- 2) Initial Impact ----------
st.header("2) Initial Impact")
c1, c2, c3 = st.columns(3)
with c1:
    t_low = st.number_input("Low/Medium threshold", min_value=0, value=40, step=1)
with c2:
    t_high = st.number_input("Medium/High threshold", min_value=0, value=80, step=1)
with c3:
    if st.button("Compute Initial Impact", type="primary", disabled=(st.session_state.questionnaire is None)):
        try:
            total = float(st.session_state.questionnaire["score"].astype(float).sum())
        except Exception:
            total = 0
        label = "High" if total >= t_high else ("Medium" if total >= t_low else "Low")
        st.session_state.initial_impact = {"total": total, "label": label}
        st.success(f"Initial Impact = {total:.0f} → **{label}**")

if st.session_state.initial_impact:
    st.metric("Initial Impact Score", f"{st.session_state.initial_impact['total']:.0f}", st.session_state.initial_impact["label"])

saved["questionnaire"] = save_upload(qdf, "questionnaire")
st.markdown("---")

# ---------- 3) Optional: Ingest into Elasticsearch ----------
st.header("3) Optional: Ingest All Files into Elasticsearch")
st.caption("Requires ELASTIC_URL / ELASTIC_INDEX / ELASTIC_API_KEY (optional) environment variables.")
ing_col1, ing_col2 = st.columns([1,3])
with ing_col1:
    do_ingest = st.button("Ingest data/* into Elasticsearch")
with ing_col2:
    st.code("python src/ingest_elastic.py --glob './data/*'", language="bash")

if do_ingest:
    try:
        ingest_main("./data/*")
        st.success("Ingestion completed. Documents indexed into Elasticsearch.")
    except Exception as e:
        st.error(f"Ingestion failed: {e}")

st.markdown("---")

# ---------- 4) Generate Risk Table via Agent ----------
st.header("4) Generate Risk Table")
gen_disabled = False  # agent has mock fallback if ES/LLM not configured

if st.button("Generate Risk Table", type="primary", disabled=gen_disabled):
    try:
        app = build_graph()
        result = app.invoke({})
        xlsx_path = Path("artifacts/output/risk_table.xlsx")
        if xlsx_path.exists():
            st.success(f"Risk table generated: {xlsx_path}")
            df = pd.read_excel(xlsx_path)
            st.dataframe(df, use_container_width=True)
            st.download_button("Download risk_table.xlsx", data=xlsx_path.read_bytes(), file_name="risk_table.xlsx")
        else:
            st.warning("No output file found. Check logs.")
    except Exception as e:
        st.error(f"Agent run failed: {e}")

st.markdown("---")
st.header("LLM Backend Status")

def check_llm_backend():
    backend = os.getenv("LLM_BACKEND", "mock")
    endpoint = os.getenv("LLM_ENDPOINT", "—")
    model = os.getenv("LLM_MODEL", "—")

    st.write(f"**Configured Backend:** `{backend}`")
    st.write(f"**Endpoint:** `{endpoint}`")
    st.write(f"**Model:** `{model}`")

    if backend == "mock":
        st.info("Using mock backend — no external LLM required.")
        return

    import requests
    try:
        if backend == "ollama":
            r = requests.get(f"{endpoint}/api/tags", timeout=5)
            if r.ok:
                tags = [m.get("name") for m in r.json().get("models", [])]
                has_model = model in tags
                if has_model:
                    st.success(f"Connected to Ollama ✅ — model `{model}` is available.")
                else:
                    st.warning(f"Ollama reachable, but model `{model}` not found. Found: {tags}")
            else:
                st.error(f"Ollama responded with status {r.status_code}: {r.text[:200]}")
        elif backend in ("vllm","tgi"):
            r = requests.get(f"{endpoint}/v1/models", timeout=5)
            if r.ok:
                js = r.json()
                st.success("Connected to OpenAI-compatible endpoint ✅")
                try:
                    names = [m.get("id") for m in js.get("data", [])]
                    st.write("Available models:", names[:10])
                    if model and model not in names:
                        st.warning(f"Configured model `{model}` not listed above.")
                except Exception:
                    pass
            else:
                st.error(f"Endpoint reachable but /v1/models failed: {r.status_code} {r.text[:160]}")
        else:
            st.warning(f"Unknown backend '{backend}'.")
    except Exception as e:
        st.error(f"LLM connectivity check failed: {e}")

check_llm_backend()

st.caption("Tip: Set LLM_BACKEND=mock to try without an LLM server; switch to vLLM/TGI/Ollama when ready.")

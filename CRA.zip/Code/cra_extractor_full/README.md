# CRA Risk Extractor (LangGraph + Llama 3.1 + Elasticsearch)
Extracts table: Risk Id, Execution Risk, Mapped L3 Risk, L3 Risk Taxonomy from Business Case, Questionnaire, L3 Taxonomy, Project Execution Risks, Previous CRA.
See README for usage.

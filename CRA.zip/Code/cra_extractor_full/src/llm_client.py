import os, json, requests

class LLMClient:
    def __init__(self, backend=None, endpoint=None, model=None, api_key=None, temperature=0.1):
        self.backend = backend or os.getenv("LLM_BACKEND","mock")
        self.endpoint = endpoint or os.getenv("LLM_ENDPOINT","http://localhost:8000/v1")
        self.model = model or os.getenv("LLM_MODEL","llama-3.1")
        self.api_key = api_key or os.getenv("LLM_API_KEY","")
        self.temperature = float(os.getenv("LLM_TEMPERATURE", temperature))

    def call(self, prompt:str, max_tokens:int=1200) -> str:
        if self.backend == "mock":
            return self._mock(prompt)
        if self.backend in ("vllm","tgi"):
            headers = {"Content-Type":"application/json"}
            if self.api_key: headers["Authorization"] = f"Bearer {self.api_key}"
            payload = {"model": self.model, "messages":[{"role":"system","content":"Return strict JSON."},{"role":"user","content":prompt}], "temperature": self.temperature, "max_tokens": max_tokens}
            r = requests.post(f"{self.endpoint}/chat/completions", headers=headers, json=payload, timeout=120)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
        if self.backend == "ollama":
            payload = {"model": self.model, "prompt": prompt, "options": {"temperature": self.temperature}}
            r = requests.post(f"{self.endpoint}/api/generate", json=payload, timeout=120)
            r.raise_for_status()
            return r.json()["response"]
        raise ValueError(f"Unknown backend: {self.backend}")

    def _mock(self, prompt:str) -> str:
        if "extract execution risks" in prompt.lower():
            return json.dumps([
                {"id":"R-001","name":"Schema incompatibility","description":"Type mismatch from SQL Server to CloudSQL may break services."},
                {"id":"R-002","name":"Regulatory approval delay","description":"Delay in MAS notification can slip go-live."}
            ])
        if "map each execution risk to l3" in prompt.lower():
            return json.dumps([
                {"id":"R-001","mapped_l3":"Migration Integrity","taxonomy":"Technology > Data Governance > Migration Integrity"},
                {"id":"R-002","mapped_l3":"Regulatory Notification/Approval","taxonomy":"Compliance > Regulatory Requirements > Regulatory Notification/Approval"}
            ])
        return "[]"

import os
from elasticsearch import Elasticsearch
from .embeddings import E5Embedder

INDEX = os.getenv("ELASTIC_INDEX","cra_corpus")

class Retriever:
    def __init__(self):
        self.es = None
        url = os.getenv("ELASTIC_URL")
        api = os.getenv("ELASTIC_API_KEY")
        if url:
            self.es = Elasticsearch(url, api_key=api)
        self.embedder = E5Embedder()

    def search(self, query:str, k=8):
        if self.es is None:
            return []
        qvec = self.embedder.embed_query(query)
        body = {
          "size": k,
          "query": {"bool":{"must":[{"multi_match":{"query":query,"fields":["text^3","title"]}}]}},
          "knn": {"field":"embedding","query_vector": qvec,"k": k,"num_candidates": 256}
        }
        resp = self.es.search(index=INDEX, body=body)
        return [hit["_source"] for hit in resp["hits"]["hits"]]

    def buckets(self):
        queries = {
            "business_case":"project objectives scope stakeholders migration",
            "questionnaire":"change impact scoring risk assessment answers",
            "taxonomy":"L3 taxonomy list mapping definitions",
            "project_risk":"project execution risk names descriptions",
            "cra":"previous CRA risk register issues lessons"
        }
        out = {}
        for k,q in queries.items():
            out[k] = self.search(q, k=6)
        return out

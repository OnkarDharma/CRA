import json

def build_evidence(buckets: dict) -> str:
    chunks = []
    for k, docs in buckets.items():
        for d in docs[:2]:
            title = d.get("title","")
            text = d.get("text","")[:1500]
            chunks.append(f"[{k}:{title}]\n{text}")
    return "\n\n".join(chunks)

def risks_json_to_text(risks: list) -> str:
    return json.dumps(risks, ensure_ascii=False)

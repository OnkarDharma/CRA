import os, json
import pandas as pd
from typing import TypedDict, Dict, Any, List
from langgraph.graph import StateGraph, END
from .llm_client import LLMClient
from .retriever import Retriever
from .prompts import EXTRACT_RISKS, MAP_TO_L3
from .extractors import build_evidence, risks_json_to_text

class CRAState(TypedDict):
    buckets: Dict[str, List[Dict[str,Any]]]
    risks: List[Dict[str,Any]]
    mapped: List[Dict[str,Any]]
    table_path: str

llm = LLMClient()
retriever = Retriever()

def retrieve_node(state: CRAState):
    return {"buckets": retriever.buckets()}

def extract_node(state: CRAState):
    evidence = build_evidence(state["buckets"])
    prompt = EXTRACT_RISKS.format(evidence=evidence)
    out = llm.call(prompt)
    try:
        risks = json.loads(out)
    except Exception:
        risks = []
    return {"risks": risks}

def map_node(state: CRAState):
    taxonomy_text = "\n".join([d.get("text","") for d in state["buckets"].get("taxonomy",[])][:3])
    prompt = MAP_TO_L3.format(risks=risks_json_to_text(state["risks"]), taxonomy=taxonomy_text)
    out = llm.call(prompt)
    try:
        mapped = json.loads(out)
    except Exception:
        mapped = []
    idx = {m.get("id"): m for m in mapped}
    rows = []
    for r in state["risks"]:
        m = idx.get(r.get("id"), {})
        rows.append({
            "Risk Id": r.get("id",""),
            "Execution Risk": r.get("name",""),
            "Mapped L3 Risk": m.get("mapped_l3",""),
            "L3 Risk Taxonomy": m.get("taxonomy","")
        })
    return {"mapped": rows}

def compose_node(state: CRAState):
    os.makedirs("artifacts/output", exist_ok=True)
    df = pd.DataFrame(state["mapped"], columns=["Risk Id","Execution Risk","Mapped L3 Risk","L3 Risk Taxonomy"])
    path = "artifacts/output/risk_table.xlsx"
    df.to_excel(path, index=False)
    with open("artifacts/output/risk_table.json","w") as f:
        json.dump(state["mapped"], f, indent=2, ensure_ascii=False)
    return {"table_path": path}

def build_graph():
    g = StateGraph(CRAState)
    g.add_node("retrieve", retrieve_node)
    g.add_node("extract", extract_node)
    g.add_node("map", map_node)
    g.add_node("compose", compose_node)
    g.set_entry_point("retrieve")
    g.add_edge("retrieve","extract")
    g.add_edge("extract","map")
    g.add_edge("map","compose")
    g.add_edge("compose", END)
    # IMPORTANT: compile the graph so we can call .invoke()
    return g.compile()

import pandas as pd

def save_table(records, xlsx_path, csv_path=None):
    df = pd.DataFrame(records)
    df.to_excel(xlsx_path, index=False)
    if csv_path:
        df.to_csv(csv_path, index=False)

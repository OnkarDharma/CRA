EXTRACT_RISKS = """Extract execution risks relevant to the migration from the following evidence.
Return strict JSON list: [{ "id": "R-###", "name": "<Execution Risk>", "description": "<one sentence>" }].
Evidence:
{evidence}
"""

MAP_TO_L3 = """Map each execution risk to an L3 risk using the taxonomy fragments. 
Return strict JSON list (same order as input):
[{"id":"R-###","mapped_l3":"<L3 risk name>","taxonomy":"<L1> > <L2> > <L3>"}]
Execution Risks:
{risks}
Taxonomy:
{taxonomy}
"""

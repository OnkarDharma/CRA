import os, argparse, json, glob
from uuid import uuid4
from elasticsearch import Elasticsearch
from .embeddings import E5Embedder

INDEX = os.getenv("ELASTIC_INDEX","cra_corpus")

MAPPING = {
  "settings": { "index": { "knn": True } },
  "mappings": {
    "properties": {
      "doc_id": {"type":"keyword"},
      "doc_type": {"type":"keyword"},
      "title": {"type":"text"},
      "text": {"type":"text"},
      "metadata": {
        "properties": {
          "tags": {"type":"keyword"},
          "source_file": {"type":"keyword"}
        }
      },
      "embedding": {
        "type":"dense_vector",
        "dims":1024,
        "index":True,
        "similarity":"cosine"
      }
    }
  }
}

def ensure_index(es: Elasticsearch):
    if not es.indices.exists(index=INDEX):
        es.indices.create(index=INDEX, body=MAPPING)

def read_text(path: str) -> str:
    from pathlib import Path
    p = Path(path)
    if p.suffix.lower()==".docx":
        from docx import Document
        d = Document(path)
        return "\n".join([p.text for p in d.paragraphs])
    elif p.suffix.lower() in [".xlsx",".xls"]:
        import pandas as pd
        try:
            df = pd.read_excel(path)
            return df.to_csv(index=False)
        except Exception:
            return ""
    elif p.suffix.lower() in [".csv",".txt"]:
        return open(path, "r", encoding="utf-8", errors="ignore").read()
    else:
        return open(path, "r", encoding="latin-1", errors="ignore").read()

def upsert(es, embedder, doc):
    if "embedding" not in doc:
        doc["embedding"] = embedder.embed_passages([doc["text"]])[0]
    es.index(index=INDEX, id=doc["doc_id"], document=doc)

def main(glob_pattern: str):
    es = Elasticsearch(os.getenv("ELASTIC_URL"), api_key=os.getenv("ELASTIC_API_KEY"))
    ensure_index(es)
    embedder = E5Embedder()

    files = glob.glob(glob_pattern)
    count = 0
    for f in files:
        text = read_text(f)
        if not text.strip():
            continue
        title = os.path.basename(f)
        lower = title.lower()
        if "business" in lower and "case" in lower: doc_type="business_case"
        elif "question" in lower: doc_type="questionnaire"
        elif "taxonomy" in lower: doc_type="taxonomy"
        elif "execution" in lower or "project" in lower: doc_type="project_risk"
        elif "cra" in lower: doc_type="cra"
        else: doc_type="other"
        payload = {
            "doc_id": str(uuid4()),
            "doc_type": doc_type,
            "title": title,
            "text": text[:300000],
            "metadata": {"source_file": f}
        }
        upsert(es, embedder, payload)
        count += 1
    print(f"Ingested {count} files into '{INDEX}'.")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--glob", required=True, help="Glob pattern, e.g. './data/*'")
    args = ap.parse_args()
    main(args.glob)

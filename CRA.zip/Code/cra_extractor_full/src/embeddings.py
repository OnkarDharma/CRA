import torch
from transformers import AutoTokenizer, AutoModel

MODEL_NAME = "intfloat/multilingual-e5-large-instruct"

class E5Embedder:
    def __init__(self, model_name: str = MODEL_NAME, device: str = None):
        self.model_name = model_name
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).eval().to(self.device)

    def embed_passages(self, texts):
        inputs = self.tokenizer([f"passage: {t}" for t in texts], padding=True, truncation=True, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self.model(**inputs).last_hidden_state.mean(dim=1)
        out = torch.nn.functional.normalize(out, p=2, dim=1)
        return out.cpu().tolist()

    def embed_query(self, text):
        inputs = self.tokenizer([f"query: {text}"], padding=True, truncation=True, return_tensors="pt").to(self.device)
        with torch.no_grad():
            out = self.model(**inputs).last_hidden_state.mean(dim=1)
        out = torch.nn.functional.normalize(out, p=2, dim=1)
        return out.cpu().tolist()[0]

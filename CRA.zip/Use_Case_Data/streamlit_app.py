
import os
import io
import json
import pandas as pd
import streamlit as st

# Optional: docx text extraction for Business Case
try:
    from docx import Document as DocxDocument
except Exception:
    DocxDocument = None

# Attempt to import the CRA agent pipeline (from the repo you downloaded earlier)
AGENT_AVAILABLE = False
try:
    from src.app import build_graph
    AGENT_AVAILABLE = True
except Exception as e:
    BUILD_ERR = str(e)

st.set_page_config(page_title="CRA Agent – On‑Prem → Cloud", layout="wide")

st.title("CRA Agent – On‑Prem → Cloud Migration")
st.caption("Upload your Business Case & Change Impact Questionnaire, score initial impact, then generate a CRA with mapped risks and impacted processes.")

# ---------- Session state ----------
if "business_case_text" not in st.session_state:
    st.session_state.business_case_text = ""
if "questionnaire" not in st.session_state:
    st.session_state.questionnaire = None
if "initial_impact" not in st.session_state:
    st.session_state.initial_impact = None
if "risks_df" not in st.session_state:
    st.session_state.risks_df = pd.DataFrame(columns=[
        "Risk ID","Evaluation Risk","L3 Risk","L3 Risk Description","Mitigation Action","Target Date"
    ])
if "impacted_processes" not in st.session_state:
    st.session_state.impacted_processes = pd.DataFrame()

# ---------- 1) Upload Business Case ----------
st.header("1) Upload Business Case for Change")
bc_file = st.file_uploader("Upload Business Case (.docx, .pdf, .txt)", type=["docx","txt","pdf"], key="bc_upl")

def extract_text(file) -> str:
    suffix = Path(file.name).suffix.lower()
    if suffix == ".txt":
        return file.read().decode("utf-8", errors="ignore")
    if suffix == ".docx" and DocxDocument is not None:
        buf = io.BytesIO(file.read())
        doc = DocxDocument(buf)
        return "\n".join([p.text for p in doc.paragraphs])
    # Basic fallback for PDF or if python-docx missing
    file.seek(0)
    return file.read().decode("latin-1", errors="ignore")

if bc_file is not None:
    st.session_state.business_case_text = extract_text(bc_file)
    st.success("Business case uploaded and parsed.")
    with st.expander("Preview Business Case Text"):
        st.text_area("Text", st.session_state.business_case_text, height=200)

# ---------- 2) Upload Change Impact Questionnaire ----------
st.header("2) Upload Change Impact Questionnaire")
qi_file = st.file_uploader("Upload Questionnaire (.xlsx, .csv)", type=["xlsx","csv"], key="qi_upl")

if qi_file is not None:
    if qi_file.name.endswith(".xlsx"):
        qdf = pd.read_excel(qi_file)
    else:
        qdf = pd.read_csv(qi_file)
    # Add editable score column if missing
    if "score" not in qdf.columns:
        qdf["score"] = 0
    st.info("You can edit the 'score' column below before calculating initial impact.")
    edited = st.data_editor(qdf, num_rows="dynamic", use_container_width=True, key="qi_editor")
    st.session_state.questionnaire = edited

# ---------- 3) Initial Impact ----------
st.header("3) Initial Impact")
col_a, col_b = st.columns([1,2])
with col_a:
    threshold_low = st.number_input("Low/Medium threshold", min_value=0, value=40, step=1)
    threshold_high = st.number_input("Medium/High threshold", min_value=0, value=80, step=1)

def classify(total, t_low, t_high):
    if total >= t_high:
        return "High"
    if total >= t_low:
        return "Medium"
    return "Low"

with col_b:
    if st.button("Initial Impact", type="primary", disabled=st.session_state.questionnaire is None):
        if st.session_state.questionnaire is None:
            st.warning("Upload a questionnaire first.")
        else:
            total = 0
            try:
                total = float(st.session_state.questionnaire["score"].astype(float).sum())
            except Exception:
                st.warning("Could not sum 'score' column; ensure it is numeric.")
            label = classify(total, threshold_low, threshold_high)
            st.session_state.initial_impact = {"total": total, "label": label}
            st.success(f"Initial Impact = {total:.0f} → **{label}**")

if st.session_state.initial_impact:
    st.metric("Initial Impact Score", f"{st.session_state.initial_impact['total']:.0f}", st.session_state.initial_impact["label"])

# ---------- 5) Generate CRA ----------
st.header("4) Generate CRA from LLM (after Initial Impact)")
gen_disabled = not (st.session_state.initial_impact and st.session_state.business_case_text)

if not AGENT_AVAILABLE:
    st.warning("Agent modules not found in this environment. Ensure the CRA agent repo is on PYTHONPATH. Error: {}".format(BUILD_ERR))

if st.button("Generate CRA", type="primary", disabled=(gen_disabled or (not AGENT_AVAILABLE))):
    # Build scenario metadata (minimal; could be enhanced with form inputs)
    scenario = {
        "countries": [],
        "ibs": [],
        "systems": [],
        "title": "Generated from UI",
        "business_case_text": st.session_state.business_case_text,
        "questionnaire_score": st.session_state.initial_impact["total"]
    }
    # Invoke the agent graph
    try:
        graph = build_graph()
        result = graph.invoke({"scenario": scenario})
        # Expect risks JSON written to artifacts, but also extract from internal state if available
        # For portability, try to read the JSON output:
        out_json = "artifacts/output/cra_agent_output.json"
        if Path(out_json).exists():
            risks = json.load(open(out_json))
        else:
            risks = result.get("risks", [])
        # Build UI dataframe
        rows = []
        for r in risks:
            rows.append({
                "Risk ID": r.get("id",""),
                "Evaluation Risk": r.get("name",""),
                "L3 Risk": " > ".join([r.get("l1_name",""), r.get("l2_name",""), r.get("l3_name","")]).strip(" > "),
                "L3 Risk Description": r.get("description",""),
                "Mitigation Action": "",
                "Target Date": ""
            })
        st.session_state.risks_df = pd.DataFrame(rows)
        st.success("CRA generated.")
    except Exception as e:
        st.error(f"Failed to generate CRA: {e}")

# Show editable risks table
if not st.session_state.risks_df.empty:
    st.subheader("CRA – Risks (Editable Mitigation & Dates)")
    st.session_state.risks_df = st.data_editor(
        st.session_state.risks_df,
        use_container_width=True,
        num_rows="dynamic",
        column_config={
            "Target Date": st.column_config.DateColumn("Target Date", format="YYYY-MM-DD")
        },
        key="cra_editor"
    )

# ---------- 7) Impacted Processes ----------
st.header("5) Impacted Processes")
proc_disabled = st.session_state.risks_df.empty

def load_process_repo():
    # Look for a process repository excel created earlier in the workspace
    candidates = [
        "Process_Repository_Aligned.xlsx",
        "Process_Repository.xlsx",
        "/mnt/data/Process_Repository_Aligned.xlsx"
    ]
    for c in candidates:
        p = Path(c)
        if p.exists():
            try:
                return pd.read_excel(p)
            except Exception:
                pass
    return pd.DataFrame()

def find_processes(risks_df, repo_df):
    if repo_df.empty or risks_df.empty:
        return pd.DataFrame()
    # naive keyword matching against Process Name and Description
    results = []
    for _, r in risks_df.iterrows():
        key = str(r.get("Evaluation Risk","")) + " " + str(r.get("L3 Risk",""))
        key_lower = key.lower()
        matches = repo_df[repo_df.apply(
            lambda row: key_lower.split(">")[-1].strip().lower() in str(row.get("Process Name","")).lower() 
                        or any(kw in str(row.get("Process Description","")).lower() for kw in key_lower.split() if len(kw)>4),
            axis=1
        )]
        # If no matches, return the top 3 by default
        if matches.empty:
            matches = repo_df.head(3)
        for _, m in matches.iterrows():
            results.append({
                "Risk ID": r.get("Risk ID",""),
                "Evaluation Risk": r.get("Evaluation Risk",""),
                "Suggested Process ID": m.get("Process ID",""),
                "Process Name": m.get("Process Name",""),
                "Process Risk Name": m.get("Process Risk Name",""),
                "Owner Business/Function": m.get("Owner Business/Function","")
            })
    return pd.DataFrame(results)

if st.button("Impacted Process", disabled=proc_disabled):
    repo_df = load_process_repo()
    if repo_df.empty:
        st.warning("No Process Repository file found in the working directory.")
    else:
        impacts = find_processes(st.session_state.risks_df, repo_df)
        st.session_state.impacted_processes = impacts
        st.success("Suggested impacted processes generated.")

if not st.session_state.impacted_processes.empty:
    st.subheader("Suggested Impacted Processes")
    st.dataframe(st.session_state.impacted_processes, use_container_width=True)

st.markdown("---")
st.caption("Tips: Configure your LLM/Elastic env vars. Place your Process_Repository_Aligned.xlsx in the working dir.")


RISK_EXTRACTION_PROMPT = """You are a change risk analyst. From the evidence below, extract atomic risks relevant to the scenario.
Return JSON list with fields: id, name, description, evidence_doc_ids (array), evidence_quotes (array).
Scenario: {scenario}
Evidence:
{evidence}
"""

MAP_PROMPT = """Classify each risk to an L3 taxonomy leaf. Use provided taxonomy fragments.
Return JSON list where each risk is augmented with: l1_name, l2_name, l3_name.
Risks:
{risks}
Taxonomy examples:
{taxonomy}
"""

SCORE_PROMPT = """Score impact (1-5) and likelihood (1-5) for each risk using questionnaire signals and evidence.
Add: score_rationale (1-2 sentences justifying scores).
Risks: {risks}
Questionnaire: {q}
"""

PROCESS_PROMPT = """Map each risk to impacted processes from Process Repository.
Add: impacted_process_ids (list), impacted_process_names (list).
Risks: {risks}
Processes: {proc}
"""

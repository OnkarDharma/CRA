CRA Agent Full Project placeholder.
Regenerate components if missing.
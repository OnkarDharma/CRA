

---

## 🐳 Docker quick start

```bash
# In the project root (where docker-compose.yml lives)
cp .env.sample .env      # optional: set env values
docker compose up --build

# Open the app
# http://localhost:8501
```

### Using the LLM service (Ollama)
The compose includes an optional `ollama` service. After `docker compose up`:
```bash
docker exec -it cra-ollama bash
ollama pull llama3.3
exit
```
Then switch the app to use Ollama:
```bash
# .env
LLM_BACKEND=ollama
LLM_ENDPOINT=http://ollama:11434
LLM_MODEL=llama3.3
```

### Using Elasticsearch
The `elasticsearch` service is included. To ingest sample documents from inside the app container:
```bash
docker exec -it cra-agent-app bash
python src/ingest.py --sample
```

Artifacts (JSON/DOCX) will appear in the host `./artifacts/` directory.

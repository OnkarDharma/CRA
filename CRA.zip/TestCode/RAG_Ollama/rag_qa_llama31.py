#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RAG Q&A with local Llama 3.1 + multilingual-e5-large-instruct embeddings

Features
--------
- Ingests DOCX/XLSX/TXT/CSV files
- Chunks content, creates embeddings with SentenceTransformer('intfloat/multilingual-e5-large-instruct')
- Stores vectors in FAISS (if available) or a NumPy+pickle fallback
- Retrieval-augmented generation with either:
    A) Ollama (default): model "llama3.1" on http://localhost:11434
    B) llama-cpp-python: provide --llama_cpp_gguf /path/to/model.gguf
- Simple CLI:
    Build index:   python rag_qa_llama31.py --build
    Ask question:  python rag_qa_llama31.py --ask "Your question"
    Rebuild:       python rag_qa_llama31.py --rebuild

Notes
-----
- The e5-* "instruct" models expect "query: ..." vs "passage: ..." prefixes.
- This script keeps things dependency-light. Install:
    pip install sentence-transformers faiss-cpu python-docx pandas openpyxl requests
  (and optionally) pip install llama-cpp-python
"""

import argparse
import os
import re
import sys
import json
import time
import pickle
import math
import glob
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict

import numpy as np

# Optional imports (we gate them at runtime)
try:
    import faiss  # type: ignore
    HAVE_FAISS = True
except Exception:
    HAVE_FAISS = False

try:
    import pandas as pd  # type: ignore
except Exception:
    pd = None

try:
    import docx  # python-docx
except Exception:
    docx = None

try:
    import requests
except Exception:
    requests = None

# Embeddings
from sentence_transformers import SentenceTransformer

INDEX_DIR = "D:\\TCS\\CRA\\TestCode\\RAG_Ollama\\Index"
EMBED_MODEL_NAME = "intfloat/multilingual-e5-large-instruct"
DEFAULT_TOP_K = 5

# Default reference files (update paths as needed)
DEFAULT_FILES = [
    "D:\\TCS\\CRA\\TestCode\\RAG_Ollama\\UsecaseData\\Business_Case_document_SQLServer_to_CloudSQL.docx",
    "D:\\TCS\\CRA\\TestCode\\RAG_Ollama\\UsecaseData\\Project_Execution_Risks.xlsx",
    "D:\\TCS\\CRA\\TestCode\\RAG_Ollama\\UsecaseData\\L3-Taxonomy_Description_with_Assessment.xlsx",
    "D:\\TCS\\CRA\\TestCode\\RAG_Ollama\\UsecaseData\\ImpactedProcess.xlsx",
]


def ensure_dir(d: str):
    os.makedirs(d, exist_ok=True)


def read_docx(path: str) -> str:
    if docx is None:
        raise RuntimeError("python-docx not installed. Install with: pip install python-docx")
    doc = docx.Document(path)
    parts = []
    for p in doc.paragraphs:
        txt = p.text.strip()
        if txt:
            parts.append(txt)
    # Tables
    for table in doc.tables:
        for row in table.rows:
            row_text = "\t".join(cell.text.strip() for cell in row.cells)
            if row_text.strip():
                parts.append(row_text)
    return "\n".join(parts)


def read_excel(path: str) -> str:
    if pd is None:
        raise RuntimeError("pandas not installed. Install with: pip install pandas openpyxl")
    xl = pd.ExcelFile(path)
    parts = []
    for sheet in xl.sheet_names:
        df = xl.parse(sheet)
        df = df.fillna("")
        csvish = df.to_csv(index=False)
        parts.append(f"### Sheet: {sheet}\n{csvish}")
    return "\n".join(parts)


def read_text_like(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def load_file(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in [".docx"]:
        return read_docx(path)
    elif ext in [".xlsx", ".xls"]:
        return read_excel(path)
    elif ext in [".txt", ".md", ".csv", ".log"]:
        return read_text_like(path)
    else:
        # Try text read as a last resort
        try:
            return read_text_like(path)
        except Exception as e:
            raise RuntimeError(f"Unsupported file type for {path}: {e}")


def clean_text(t: str) -> str:
    # Light cleanup
    t = re.sub(r"\r\n?", "\n", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def chunk_text(text: str, max_chars: int = 1200, overlap: int = 120) -> List[str]:
    # Simple char-based chunking that tries to split at sentence boundaries
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks, cur = [], ""
    for s in sentences:
        if not cur:
            cur = s
        elif len(cur) + 1 + len(s) <= max_chars:
            cur += " " + s
        else:
            chunks.append(cur)
            # overlap from end of previous chunk
            tail = cur[-overlap:] if overlap > 0 else ""
            cur = (tail + " " + s).strip()
    if cur:
        chunks.append(cur)
    return chunks


def embed_passages(model: SentenceTransformer, passages: List[str], batch_size: int = 32) -> np.ndarray:
    # e5-instruct expects "passage: ..." prefix for documents
    inputs = [f"passage: {p}" for p in passages]
    vecs = model.encode(inputs, batch_size=batch_size, show_progress_bar=True, normalize_embeddings=True)
    return np.array(vecs, dtype=np.float32)


def embed_queries(model: SentenceTransformer, queries: List[str]) -> np.ndarray:
    # e5-instruct expects "query: ..." prefix for queries
    inputs = [f"query: {q}" for q in queries]
    vecs = model.encode(inputs, show_progress_bar=False, normalize_embeddings=True)
    return np.array(vecs, dtype=np.float32)


@dataclass
class StorePaths:
    meta_path: str
    faiss_index_path: str
    npy_vectors_path: str
    pickle_store_path: str


def get_store_paths(index_dir: str = INDEX_DIR) -> StorePaths:
    ensure_dir(index_dir)
    return StorePaths(
        meta_path=os.path.join(index_dir, "meta.json"),
        faiss_index_path=os.path.join(index_dir, "faiss.index"),
        npy_vectors_path=os.path.join(index_dir, "vectors.npy"),
        pickle_store_path=os.path.join(index_dir, "store.pkl"),
    )


def save_store(passages: List[str], file_spans: List[Tuple[str, int, int]], vectors: np.ndarray, have_faiss: bool):
    sp = get_store_paths()
    meta = {
        "have_faiss": bool(have_faiss),
        "count": len(passages),
        "files": list(sorted({p for p, _, _ in file_spans})),
        "created_at": time.time(),
        "embed_model": EMBED_MODEL_NAME,
        "dim": int(vectors.shape[1]) if vectors is not None else None,
    }
    with open(sp.meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    # Always save vectors.npy + store.pkl (fallback & metadata)
    np.save(sp.npy_vectors_path, vectors)
    with open(sp.pickle_store_path, "wb") as f:
        pickle.dump({"passages": passages, "file_spans": file_spans}, f)

    # Save FAISS if available
    if have_faiss:
        index = faiss.IndexFlatIP(vectors.shape[1])
        index.add(vectors)
        faiss.write_index(index, sp.faiss_index_path)


def load_store() -> Tuple[List[str], List[Tuple[str, int, int]], np.ndarray, Optional[object], Dict]:
    sp = get_store_paths()
    if not (os.path.exists(sp.meta_path) and os.path.exists(sp.pickle_store_path) and os.path.exists(sp.npy_vectors_path)):
        raise RuntimeError("Index not found. Build it first with --build.")

    with open(sp.meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    with open(sp.pickle_store_path, "rb") as f:
        store = pickle.load(f)
    vectors = np.load(sp.npy_vectors_path)

    faiss_index = None
    if meta.get("have_faiss") and HAVE_FAISS and os.path.exists(sp.faiss_index_path):
        faiss_index = faiss.read_index(sp.faiss_index_path)

    passages = store["passages"]
    file_spans = store["file_spans"]
    return passages, file_spans, vectors, faiss_index, meta


def cosine_sim(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    # both should be L2-normalized; still guard normalize
    def norm(x): return x / max(np.linalg.norm(x) + 1e-12, 1e-12)
    a = np.array([norm(v) for v in a], dtype=np.float32)
    b = np.array([norm(v) for v in b], dtype=np.float32)
    return a @ b.T


def retrieve(emb_model: SentenceTransformer, query: str, top_k: int = DEFAULT_TOP_K) -> List[Tuple[float, str]]:
    passages, _, vectors, faiss_index, meta = load_store()
    qv = embed_queries(emb_model, [query]).astype(np.float32)  # shape (1, d)

    if faiss_index is not None:
        D, I = faiss_index.search(qv, top_k)
        idxs = I[0].tolist()
        sims = D[0].tolist()
    else:
        sims = cosine_sim(qv, vectors)[0]
        idxs = np.argsort(-sims)[:top_k].tolist()
        sims = [float(sims[i]) for i in idxs]

    results = [(sims[i], passages[idxs[i]]) for i in range(len(idxs))]
    return results


# ------------------------- Llama 3.1 backends --------------------------

def call_ollama_llama31(prompt: str, system: Optional[str] = None, model: str = "llama3.1", base_url: str = "http://localhost:11434") -> str:
    if requests is None:
        raise RuntimeError("The 'requests' library is required for Ollama backend. Install with: pip install requests")
    url = f"{base_url}/api/generate"
    full_prompt = prompt if system is None else f"<<SYS>>\n{system}\n<</SYS>>\n{prompt}"
    payload = {
        "model": model,
        "prompt": full_prompt,
        "stream": False,
        "options": {"temperature": 0.1, "num_ctx": 8192}
    }
    r = requests.post(url, json=payload, timeout=600)
    r.raise_for_status()
    data = r.json()
    return data.get("response", "").strip()


def call_llama_cpp(prompt: str, system: Optional[str] = None, gguf_path: Optional[str] = None) -> str:
    if gguf_path is None:
        raise RuntimeError("Please provide --llama_cpp_gguf /path/to/model.gguf to use llama-cpp backend.")
    try:
        from llama_cpp import Llama
    except Exception as e:
        raise RuntimeError("llama-cpp-python not installed. Install with: pip install llama-cpp-python") from e

    llm = Llama(
        model_path=gguf_path,
        n_ctx=8192,
        n_threads=max(1, os.cpu_count() // 2),
        verbose=False,
        logits_all=False,
        seed=42,
        n_gpu_layers=-1  # auto if compiled with BLAS/Metal/CUDA
    )
    sys_prefix = (system + "\n") if system else ""
    res = llm.create_completion(
        prompt=sys_prefix + prompt,
        temperature=0.1,
        max_tokens=1024,
        stop=["</s>"]
    )
    # Compatible return handling
    if isinstance(res, dict) and "choices" in res and len(res["choices"]) > 0:
        return res["choices"][0]["text"].strip()
    return str(res)


def build_prompt(query: str, contexts: List[str]) -> Tuple[str, str]:
    system = (
        "You are a careful, concise assistant. Answer the user's question strictly using the provided context.\n"
        "If the answer is not in the context, say you don't have enough information. Cite passage numbers like [P1], [P2]."
    )
    numbered = []
    for i, c in enumerate(contexts, 1):
        numbered.append(f"[P{i}] {c}")
    context_block = "\n\n".join(numbered)
    user = (
        f"Context passages:\n{context_block}\n\n"
        f"User question: {query}\n\n"
        "Answer:"
    )
    return system, user


def build_index(files: List[str]):
    print(f"Embedding with: {EMBED_MODEL_NAME}")
    model = SentenceTransformer(EMBED_MODEL_NAME)

    passages = []
    file_spans = []  # (file, chunk_start_idx, chunk_end_idx)
    for f in files:
        if not os.path.exists(f):
            print(f"[WARN] File not found, skipping: {f}")
            continue
        print(f"Reading: {f}")
        raw = load_file(f)
        raw = clean_text(raw)
        chunks = chunk_text(raw)
        if not chunks:
            continue
        start = len(passages)
        passages.extend(chunks)
        end = len(passages)
        file_spans.append((f, start, end))

    if not passages:
        raise RuntimeError("No passages to index. Check your file paths.")

    vectors = embed_passages(model, passages)
    save_store(passages, file_spans, vectors, HAVE_FAISS)
    print(f"Indexed {len(passages)} passages. Stored in '{INDEX_DIR}'.")


def ask_question(query: str, top_k: int = DEFAULT_TOP_K, backend: str = "ollama", gguf_path: Optional[str] = None, model_name: str = "llama3.1") -> str:
    model = SentenceTransformer(EMBED_MODEL_NAME)
    hits = retrieve(model, query, top_k=top_k)
    contexts = [c for _, c in hits]
    system, user = build_prompt(query, contexts)
    if backend == "ollama":
        return call_ollama_llama31(user, system=system, model=model_name)
    elif backend == "llama_cpp":
        return call_llama_cpp(user, system=system, gguf_path=gguf_path)
    else:
        raise ValueError("backend must be 'ollama' or 'llama_cpp'")


def parse_args():
    ap = argparse.ArgumentParser(description="RAG Q&A with local Llama 3.1 and e5 embeddings")
    ap.add_argument("--build", action="store_true", help="Build index from files")
    ap.add_argument("--rebuild", action="store_true", help="Delete old index and rebuild")
    ap.add_argument("--files", nargs="*", default=DEFAULT_FILES, help="Files or globs to include")
    ap.add_argument("--ask", type=str, help="Question to ask")
    ap.add_argument("--top_k", type=int, default=DEFAULT_TOP_K, help="Top-k passages to retrieve")
    ap.add_argument("--backend", choices=["ollama", "llama_cpp"], default="ollama", help="LLM backend to use")
    ap.add_argument("--llama_cpp_gguf", type=str, default=None, help="Path to local Llama 3.1 .gguf (for llama-cpp backend)")
    ap.add_argument("--model_name", type=str, default="llama3.1", help="Model name for Ollama backend")
    return ap.parse_args()


def expand_globs(paths: List[str]) -> List[str]:
    out = []
    for p in paths:
        matches = glob.glob(p) or [p]
        out.extend(matches)
    # de-dupe while preserving order
    seen = set()
    uniq = []
    for x in out:
        if x not in seen:
            seen.add(x)
            uniq.append(x)
    return uniq


def main():
    args = parse_args()
    files = expand_globs(args.files)

    if args.rebuild:
        # remove index dir
        if os.path.isdir(INDEX_DIR):
            for root, dirs, fnames in os.walk(INDEX_DIR, topdown=False):
                for n in fnames:
                    try:
                        os.remove(os.path.join(root, n))
                    except Exception:
                        pass
                for d in dirs:
                    try:
                        os.rmdir(os.path.join(root, d))
                    except Exception:
                        pass
            try:
                os.rmdir(INDEX_DIR)
            except Exception:
                pass
        ensure_dir(INDEX_DIR)

    if args.build or args.rebuild:
        build_index(files)
        if args.ask:
            print("\n---\n")
        else:
            return

    if args.ask:
        print(f"Question: {args.ask}\n")
        try:
            answer = ask_question(
                args.ask,
                top_k=args.top_k,
                backend=args.backend,
                gguf_path=args.llama_cpp_gguf,
                model_name=args.model_name,
            )
        except Exception as e:
            print(f"[ERROR] Failed to get answer: {e}")
            sys.exit(2)
        print("Answer:\n")
        print(answer)
    elif not (args.build or args.rebuild):
        # If user didn't specify any action, print help
        print("Nothing to do. Use --build to index files and/or --ask \"Your question\" to query.")


if __name__ == "__main__":
    main()

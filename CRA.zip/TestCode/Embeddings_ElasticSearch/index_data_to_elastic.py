#!/usr/bin/env python3
"""
Index mixed documents (txt/docx/excel) from ./data into Elasticsearch with
intfloat/multilingual-e5-large-instruct embeddings.
"""
import os
from pathlib import Path
from io import StringIO
from typing import Optional, Dict, Any

# ---- Install deps (pip):
# pip install "elasticsearch>=8" sentence-transformers torch python-docx pandas openpyxl xlrd

from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError
from sentence_transformers import SentenceTransformer
import pandas as pd

# ----------- Configuration -------------
DATA_DIR = "D:\\TCS\\CRA\\TestCode\\Embeddings_ElasticSearch\\UsecaseData"
INDEX_NAME = "doc_embeddings"
ALLOWED_SUFFIXES = {".txt", ".docx", ".xlsx", ".xls"}

# Elasticsearch connection via env (works for secured or unsecured local ES):
# ES_URL (default http://localhost:9200), ES_USER, ES_PASSWORD, ES_API_KEY, ES_CA_CERTS
ES_URL = os.getenv("ES_URL", "http://localhost:9200")
ES_USER = os.getenv("ES_USER")
ES_PASSWORD = os.getenv("ES_PASSWORD")
ES_API_KEY = os.getenv("ES_API_KEY")  # format "id:api_key" or base64
ES_CA_CERTS = os.getenv("ES_CA_CERTS")  # e.g., "/path/to/http_ca.crt"


def make_es_client() -> Elasticsearch:
    kwargs: Dict[str, Any] = {}
    if ES_CA_CERTS:
        kwargs["ca_certs"] = ES_CA_CERTS

    if ES_API_KEY:
        return Elasticsearch(ES_URL, api_key=ES_API_KEY, **kwargs)
    if ES_USER and ES_PASSWORD:
        return Elasticsearch(ES_URL, basic_auth=(ES_USER, ES_PASSWORD), **kwargs)
    # unsecured local dev
    return Elasticsearch(ES_URL, **kwargs)


def ensure_index(es: Elasticsearch, dim: int) -> None:
    """Create index with dense_vector mapping if it doesn't exist."""
    try:
        exists = es.indices.exists(index=INDEX_NAME)
    except Exception:
        exists = False

    if exists:
        # Optionally validate dims; skip for brevity
        return

    body = {
        "settings": {
            # Enable kNN (ES/Opensearch naming differs; for ES this is fine even if ignored)
            "index": {"knn": True}
        },
        "mappings": {
            "properties": {
                "path": {"type": "keyword"},
                "filename": {"type": "keyword"},
                "content": {"type": "text"},
                "embedding": {
                    "type": "dense_vector",
                    "dims": dim,
                    "index": True,                # ES 8+ vector indexing
                    "similarity": "cosine"
                },
            }
        },
    }
    es.indices.create(index=INDEX_NAME, mappings=body["mappings"], settings=body["settings"])


def read_text(path: Path) -> Optional[str]:
    """Extract plain text from .txt, .docx, .xlsx, .xls."""
    try:
        suf = path.suffix.lower()
        if suf == ".txt":
            return path.read_text(encoding="utf-8", errors="ignore")

        if suf == ".docx":
            from docx import Document
            doc = Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text)

        if suf in {".xlsx", ".xls"}:
            # Read all sheets and collapse to a text blob
            sheets: Dict[str, pd.DataFrame] = pd.read_excel(path, sheet_name=None, dtype=str)
            parts = []
            for name, df in sheets.items():
                if df is None or df.empty:
                    continue
                df = df.fillna("")
                # Concatenate rows as space-joined values for a readable text dump
                text_rows = [" ".join(row) for row in df.astype(str).values.tolist()]
                parts.append(f"# Sheet: {name}\n" + "\n".join(text_rows))
            return "\n\n".join(parts).strip()
    except Exception as e:
        print(f"[WARN] Failed to read {path}: {e}")

    return None


def main():
    # 1) Load model and get embedding dimension
    model = SentenceTransformer("intfloat/multilingual-e5-large-instruct")
    dim = model.get_sentence_embedding_dimension()

    # 2) Connect to Elasticsearch and ensure index
    es = make_es_client()
    ensure_index(es, dim)

    # 3) Walk data folder
    if not DATA_DIR.exists():
        raise SystemExit(f"Data folder not found: {DATA_DIR.resolve()}")

    files = [p for p in DATA_DIR.rglob("*") if p.is_file() and p.suffix.lower() in ALLOWED_SUFFIXES]
    if not files:
        print("No supported files found in ./data")
        return

    print(f"Found {len(files)} files. Embedding and indexing...")

    # 4) Process files
    for path in sorted(files):
        text = read_text(path)
        if not text or not text.strip():
            print(f"[SKIP] Empty or unreadable: {path}")
            continue

        # E5-instruct expects "passage: ..." for documents
        model_input = "passage: " + text.strip()
        emb = model.encode(model_input, normalize_embeddings=True).tolist()

        doc = {
            "path": str(path.resolve()),
            "filename": path.name,
            "content": text,
            "embedding": emb,
        }

        # Use stable id so re-runs upsert the same doc
        doc_id = str(path.resolve())
        es.index(index=INDEX_NAME, id=doc_id, document=doc)
        print(f"[OK] {path}")

    print("Done.")


if __name__ == "__main__":
    main()

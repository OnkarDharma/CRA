# streamlit_app.py
# Requirements: pip install streamlit pandas openpyxl xlsxwriter python-docx pypdf2
import io
import os
import math
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Change Impact Scoring", page_icon="📊", layout="wide")

st.title("📊 Change Impact Questionnaire – Scoring App")
st.write(
    "Upload your Change Impact Questionnaire, assign **Score** values (1, 3, or 5), categorize the total, and save. You can also upload a **Business Use Case** file, which will be saved to a local **data/** folder."
)

# Ensure data folder exists for saving uploads
DATA_DIR = "D:\\TCS\\CRA\\TestCode\\StreamlitCode\\Uploaded_Data"
os.makedirs(DATA_DIR, exist_ok=True)

# --- Sidebar: Instructions ---
with st.sidebar:
    st.header("How it works")
    st.markdown(
        """
        **A. Questionnaire**
        1) Upload Excel/CSV with your questions.
        2) Edit the **Score** column (options: **1**, **3**, **5**).
        3) See **Total Score** and **Category**.
        4) Click **Save results** to download a scored Excel.

        **B. Business Use Case**
        • Upload any supporting file; it will be saved to the local `data/` folder.
        """
    )
    st.caption("Only the **Score** column is editable; original columns are locked.")

# =============================
# Section B: Business Use Case Upload (saved to data/)
# =============================
st.subheader("📁 Upload Business Use Case (saved to data/)")
biz_file = st.file_uploader(
    "Upload Business Use Case file",
    type=["pdf", "docx", "xlsx", "xls", "csv", "pptx", "txt"],
    accept_multiple_files=False,
    help="Supported: PDF, DOCX, XLSX/XLS, CSV, PPTX, TXT",
    key="biz_upload",
)

if biz_file is not None:
    save_path = os.path.join(DATA_DIR, biz_file.name)
    try:
        with open(save_path, "wb") as f:
            f.write(biz_file.getbuffer())
        st.success(f"Saved Business Use Case to: {save_path}")
    except Exception as e:
        st.error(f"Failed to save file: {e}")

st.markdown("---")

# =============================
# Section A: Change Impact Questionnaire
# =============================
st.subheader("📝 Upload Change Impact Questionnaire (Excel/CSV)")
qi_file = st.file_uploader(
    "Upload Questionnaire",
    type=["xlsx", "xls", "csv"],
    accept_multiple_files=False,
    help="Excel (.xlsx/.xls) or CSV",
    key="qi_upload",
)

if "download_ready" not in st.session_state:
    st.session_state.download_ready = False
    st.session_state.download_bytes = None
    st.session_state.download_name = None

if qi_file is not None:
    # --- Load data ---
    try:
        if qi_file.name.lower().endswith((".xlsx", ".xls")):
            df = pd.read_excel(qi_file)
        else:
            df = pd.read_csv(qi_file)
    except Exception as e:
        st.error(f"Could not read the questionnaire file: {e}")
        st.stop()

    if df.empty:
        st.warning("The uploaded questionnaire appears to be empty.")
        st.stop()

    # Ensure a Score column exists
    if "Score" not in df.columns:
        df["Score"] = 3  # default midpoint

    # Coerce invalid Score values to nearest valid (1,3,5)
    def coerce_score(val):
        try:
            v = int(val)
        except Exception:
            return 3
        # Snap to nearest of {1,3,5}
        choices = [1, 3, 5]
        return min(choices, key=lambda x: abs(x - v))

    df["Score"] = df["Score"].apply(coerce_score)

    st.markdown("### Review & Edit Scores")

    # Build column config so only Score is editable and limited to {1,3,5}
    col_cfg = {
        "Score": st.column_config.SelectboxColumn(
            label="Score",
            help="Allowed values: 1 (Low), 3 (Medium), 5 (High)",
            options=[1, 3, 5],
            required=True,
        )
    }

    disabled_cols = [c for c in df.columns if c != "Score"]

    edited_df = st.data_editor(
        df,
        column_config=col_cfg,
        disabled=disabled_cols,
        use_container_width=True,
        num_rows="fixed",
        key="qi_editor",
    )

    # Validate again (defensive)
    if not edited_df["Score"].isin([1, 3, 5]).all():
        st.error("All Score values must be 1, 3, or 5.")
        st.stop()

    # --- Scoring summary ---
    n = len(edited_df)
    total_score = int(edited_df["Score"].sum())
    min_total = 1 * n
    max_total = 5 * n
    # Normalize to 0–100 for category logic
    norm = 0 if max_total == min_total else 100 * (total_score - min_total) / (max_total - min_total)

    def categorize(norm_score: float) -> str:
        # Thresholds: <40 Low, 40–69 Medium, ≥70 High
        if norm_score < 15:
            return "Low"
        elif norm_score < 45:
            return "Medium"
        else:
            return "High"

    category = categorize(norm)

    st.markdown("---")
    c1, c2, c3, c4 = st.columns([1, 1, 1, 2])
    with c1:
        st.metric("Items", n)
    with c2:
        st.metric("Total Score", total_score)
    with c3:
        st.metric("Max Possible", max_total)
    with c4:
        st.metric("Category", category)

    st.caption(
        f"Scoring scale adapts to your row count (min {min_total}, max {max_total}). Thresholds: <40% Low, 40–69% Medium, ≥70% High."
    )

    # --- Save results (download) ---
    st.markdown("### Save results")
    base_name = qi_file.name.rsplit(".", 1)[0]
    out_name = f"{base_name}_scored.xlsx"

    if st.button("💾 Save results"):
        output = io.BytesIO()
        try:
            with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
                # Write scored data
                scored_df = edited_df.copy()
                # Add summary rows at the bottom
                scored_df.to_excel(writer, index=False, sheet_name="Scored Data")
                wb = writer.book
                ws = writer.sheets["Scored Data"]
                last_row = len(scored_df) + 2
                ws.write(last_row, 0, "Items")
                ws.write(last_row, 1, n)
                ws.write(last_row + 1, 0, "Total Score")
                ws.write(last_row + 1, 1, total_score)
                ws.write(last_row + 2, 0, "Max Possible")
                ws.write(last_row + 2, 1, max_total)
                ws.write(last_row + 3, 0, "Category")
                ws.write(last_row + 3, 1, category)
            st.session_state.download_bytes = output.getvalue()
            st.session_state.download_name = out_name
            st.session_state.download_ready = True
            st.success("Results packaged. Use the download button below.")
        except Exception as e:
            st.error(f"Failed to generate output: {e}")

    if st.session_state.download_ready and st.session_state.download_bytes:
        st.download_button(
            label=f"⬇️ Download {st.session_state.download_name}",
            data=st.session_state.download_bytes,
            file_name=st.session_state.download_name,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

else:
    st.info("Upload an Excel/CSV questionnaire to begin scoring. You can also upload a Business Use Case file above to save it to data/.")
